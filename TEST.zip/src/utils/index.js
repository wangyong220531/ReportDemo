import test from "./test"

export default {
    test: test
}
