function test() {
    console.log("我是test！")
}

export default test
